package amazononline.customermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomermanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
